package com.smartlab.wpslidingmenu;

import android.util.Log;

import com.google.firebase.messaging.FirebaseMessagingService;
import com.google.firebase.messaging.RemoteMessage;

//import me.leolin.shortcutbadger.ShortcutBadger;

import static android.content.ContentValues.TAG;

/**
 * Created by Syuk on 12/8/2018.
 */

//class extending FirebaseMessagingService
public class MyFirebaseMessagingService extends FirebaseMessagingService {
    int countMsg = 0;

    @Override
    public void onMessageReceived(RemoteMessage remoteMessage) {
        super.onMessageReceived(remoteMessage);



        //if the message contains data payload
        //It is a map of custom keyvalues
        //we can read it easily
        if(remoteMessage.getData().size() > 0){
            //handle the data message here
        }


        //getting the title and the body
        String title = remoteMessage.getNotification().getTitle();
        String body = remoteMessage.getNotification().getBody();

        //firebase badge
        //countMsg = countMsg++;
        //ShortcutBadger.applyCount(MyFirebaseMessagingService.this, 1);

        //then here we can use the title and body to build a notification
    }


}

package com.smartlab.wpslidingmenu;



import com.journeyapps.barcodescanner.CaptureActivity;

public class CaptureActivityPortrait extends CaptureActivity {
//Nothing in side.

}

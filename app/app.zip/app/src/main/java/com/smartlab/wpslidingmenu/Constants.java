package com.smartlab.wpslidingmenu;

/**
 * Created by Syuk on 12/8/2017.
 */

public class Constants {

    public static final String CHANNEL_ID = "my_channel_01";
    public static final String CHANNEL_NAME = "Syux Test";
    public static final String CHANNEL_DESCRIPTION = "Syux testtttttt";
}
package com.smartlab.wpslidingmenu;

public class variable {

    String mUri = "";

    public void setUri(String uri){
        mUri = uri;
    }

    public String getUri(){
        return mUri;
    }
}
